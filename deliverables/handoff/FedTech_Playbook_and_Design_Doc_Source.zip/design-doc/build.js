const fs=require('fs');
const d=require('docx');
const {Document,Packer,Paragraph,TextRun,Table,TableRow,TableCell,WidthType,ShadingType,BorderStyle,HeadingLevel,AlignmentType,PageBreak,Header,Footer,PageNumber,TableOfContents,LevelFormat}=d;
const C=JSON.parse(fs.readFileSync('content.json'));
const W=10080, INK='16181D', OR='C2410C', ORL='FDEEE4', BL='1D4ED8', BLL='EEF2FD', GR='4A5059', GRL='F2F3F5', LINE='C9CDD4';
const FONT='Arial';
const t=(text,o={})=>new TextRun({text,font:FONT,...o});
const p=(runs,o={})=>new Paragraph({children:Array.isArray(runs)?runs:[t(runs)],spacing:{after:120},...o});
const brd=(c=LINE)=>({top:{style:BorderStyle.SINGLE,size:4,color:c},bottom:{style:BorderStyle.SINGLE,size:4,color:c},left:{style:BorderStyle.SINGLE,size:4,color:c},right:{style:BorderStyle.SINGLE,size:4,color:c}});
function cell(children,width,o={}){return new TableCell({children:Array.isArray(children)?children:[children],width:{size:width,type:WidthType.DXA},margins:{top:80,bottom:80,left:120,right:120},borders:brd(o.border||LINE),shading:o.fill?{type:ShadingType.CLEAR,color:'auto',fill:o.fill}:undefined,columnSpan:o.span});}
function table(cols,rows,widths){
  widths=widths||cols.map(()=>Math.floor(W/cols.length)); const sum=widths.reduce((a,b)=>a+b,0); widths[widths.length-1]+=W-sum;
  const head=new TableRow({tableHeader:true,children:cols.map((c,i)=>cell(p([t(c,{bold:true,size:18,color:INK})],{spacing:{after:0}}),widths[i],{fill:GRL}))});
  const body=rows.map(r=>new TableRow({children:r.map((v,i)=>cell(p([t(v||'',{size:19,color:v&&v.startsWith('[')?GR:INK})],{spacing:{after:0}}),widths[i]))}));
  return new Table({width:{size:W,type:WidthType.DXA},columnWidths:widths,rows:[head,...body]});
}
function fields(rows){
  const w=[3400,W-3400];
  return new Table({width:{size:W,type:WidthType.DXA},columnWidths:w,rows:rows.map(r=>new TableRow({children:[cell(p([t(r,{bold:true,size:19})],{spacing:{after:0}}),w[0],{fill:GRL}),cell(p([t('[Enter]',{size:19,color:GR})],{spacing:{after:0}}),w[1])]}))});
}
function box(label,lines,fill,color,italic){
  const kids=[p([t(label,{bold:true,size:17,color,characterSpacing:20})],{spacing:{after:80}})];
  lines.forEach(l=>kids.push(p([t(l,{size:19,color,italics:!!italic})],{spacing:{after:60}})));
  return new Table({width:{size:W,type:WidthType.DXA},columnWidths:[W],rows:[new TableRow({children:[new TableCell({children:kids,width:{size:W,type:WidthType.DXA},margins:{top:120,bottom:100,left:180,right:180},shading:{type:ShadingType.CLEAR,color:'auto',fill},borders:{top:{style:BorderStyle.NONE,size:0,color:'FFFFFF'},bottom:{style:BorderStyle.NONE,size:0,color:'FFFFFF'},right:{style:BorderStyle.NONE,size:0,color:'FFFFFF'},left:{style:BorderStyle.SINGLE,size:24,color}}})]})]});
}
const sp=(n=120)=>new Paragraph({children:[],spacing:{after:n}});
const kids=[];
// Cover
kids.push(sp(1800));
kids.push(p([t('CHALLENGE DESIGN DOCUMENT',{bold:true,size:22,color:GR,characterSpacing:40})]));
kids.push(p([t('[Challenge name]',{bold:true,size:60,color:INK})],{spacing:{after:200}}));
kids.push(p([t('Prepared by FedTech for [Client agency and office], under NOIS3 task order [NOIS3-XXX] with NASA CoECI.',{size:24,color:'2A2E35'})],{spacing:{after:600}}));
kids.push(fields(['Task order','Client agency and office','Version and date','Status (draft, in clearance, cleared)','FedTech Program Manager','Agency decision maker','CoECI COR and backup contact']));
kids.push(sp(400));
kids.push(box('CLIENT NAMED SECTIONS',['The client has asked that this document address prize structure, timeline, submission requirements, evaluation criteria and intellectual property. Those sections are marked "Client named" below. The rest are FedTech additions drawn from the challenge playbook and federal prize guidance.'],ORL,'7A2A07'));
kids.push(new Paragraph({children:[new PageBreak()]}));
// Document control
kids.push(new Paragraph({heading:HeadingLevel.HEADING_1,children:[t('Document control')]}));
kids.push(table(['Version','Date','Author','Changes'],[['0.1','','FedTech','First draft'],['','','',''],['','','','']],[1400,1800,2200,4680]));
kids.push(sp());
kids.push(new Paragraph({heading:HeadingLevel.HEADING_2,children:[t('Distribution')]}));
kids.push(p('CoECI and the backup CoECI contact are copied on every draft and every comment round. The client agency approves this document; CoECI\'s COR oversees the task order, and any scope change goes to the COR in writing.'));
kids.push(new Paragraph({heading:HeadingLevel.HEADING_2,children:[t('How to use this template')]}));
['Open this document at kickoff and fill it in during the design session.','Red draft notes are for the drafter. Delete every one before the document goes to the client.','Blue boxes list the questions to confirm with the client in each section. Record answers in the section, and log anything still open in section 17.','Use only the terms agreed in the glossary (Annex A).','Allow for agency clearance in the schedule. Some agencies take a month or more. Publish nothing until the document clears.'].forEach(x=>kids.push(new Paragraph({numbering:{reference:'b',level:0},children:[t(x,{size:20})],spacing:{after:80}})));
kids.push(new Paragraph({children:[new PageBreak()]}));
kids.push(new Paragraph({heading:HeadingLevel.HEADING_1,children:[t('Contents')]}));
kids.push(new TableOfContents('Contents',{hyperlink:true,headingStyleRange:'1-1'}));
kids.push(p([t('Right-click the table and choose Update Field if page numbers do not appear.',{size:17,color:GR,italics:true})]));
// Sections
for(const s of C.sections){
  kids.push(new Paragraph({children:[new PageBreak()]}));
  const h=[t(`${s.n}. ${s.title}`)];
  kids.push(new Paragraph({heading:HeadingLevel.HEADING_1,children:h}));
  const meta=[t(`Feeds playbook workflows: ${s.wf}`,{size:17,color:GR})];
  if(s.client) meta.push(t('     CLIENT NAMED',{size:17,bold:true,color:OR}));
  kids.push(p(meta));
  kids.push(p([t(s.purpose,{size:21})]));
  kids.push(box('DRAFT NOTE · DELETE BEFORE SENDING TO CLIENT',[s.guidance],'FFE5E5','E00000',true));
  kids.push(sp(100));
  kids.push(box('KEY QUESTIONS TO CONFIRM WITH THE CLIENT',s.kq.map(q=>'☐  '+q),BLL,'1E3A8A'));
  kids.push(sp(160));
  for(const b of s.blocks){
    if(b.type==='fields') kids.push(fields(b.rows));
    else if(b.type==='table') kids.push(table(b.cols,b.rows,b.widths));
    else kids.push(p(b.text));
    kids.push(sp(160));
  }
}
// Annexes
kids.push(new Paragraph({children:[new PageBreak()]}));
kids.push(new Paragraph({heading:HeadingLevel.HEADING_1,children:[t('Annex A. Glossary')]}));
kids.push(p('Agree each term with the client and use only the agreed words in the rules, site, platform, Challenge.gov listing and outreach.'));
kids.push(table(['Term','Common meaning','Agreed definition'],C.glossary.map(g=>[g[0],g[1],'']).concat([['[Add a term]','','']]),[2700,3800,3580]));
kids.push(new Paragraph({children:[new PageBreak()]}));
kids.push(new Paragraph({heading:HeadingLevel.HEADING_1,children:[t('Annex B. Rules and compliance questions')]}));
kids.push(p('FedTech drafts the rules; the agency and its counsel decide them. A planning aid, not legal advice.'));
kids.push(table(['Topic','Question to settle','Answer','Confirmed by'],C.compliance.map(c=>[c[0],c[1],'','']),[1900,4100,2400,1680]));
kids.push(new Paragraph({children:[new PageBreak()]}));
kids.push(new Paragraph({heading:HeadingLevel.HEADING_1,children:[t('Approval')]}));
kids.push(p('Approval confirms this version as the reference for the challenge. Later changes come back to this document, and changes after clearance may restart clearance.'));
kids.push(table(['Role','Name and office','Signature','Date'],[['Client agency approver','','',''],['Agency clearance complete','','',''],['CoECI COR (acknowledged)','','',''],['FedTech Program Manager','','','']],[2800,3200,2480,1600]));
const doc=new Document({
 creator:'FedTech',title:'Challenge Design Document',
 styles:{default:{document:{run:{font:FONT,size:20,color:INK}}},
  paragraphStyles:[
   {id:'Heading1',name:'Heading 1',basedOn:'Normal',next:'Normal',quickFormat:true,run:{font:FONT,size:36,bold:true,color:INK},paragraph:{spacing:{before:120,after:120},outlineLevel:0}},
   {id:'Heading2',name:'Heading 2',basedOn:'Normal',next:'Normal',quickFormat:true,run:{font:FONT,size:26,bold:true,color:INK},paragraph:{spacing:{before:240,after:100},outlineLevel:1}}]},
 numbering:{config:[{reference:'b',levels:[{level:0,format:LevelFormat.BULLET,text:'•',alignment:AlignmentType.LEFT,style:{paragraph:{indent:{left:360,hanging:240}}}}]}]},
 features:{updateFields:true},
 sections:[{properties:{page:{size:{width:12240,height:15840},margin:{top:1080,bottom:1080,left:1080,right:1080}}},
  headers:{default:new Header({children:[p([t('Challenge Design Document · [Challenge name] · [Version]',{size:16,color:GR})],{alignment:AlignmentType.RIGHT})]})},
  footers:{default:new Footer({children:[p([t('FedTech · Prepared for [Client agency] · Page ',{size:16,color:GR}),new TextRun({children:[PageNumber.CURRENT],font:FONT,size:16,color:GR})],{alignment:AlignmentType.RIGHT})]})},
  children:kids}]});
Packer.toBuffer(doc).then(b=>{fs.writeFileSync('Challenge_Design_Document_Template.docx',b);console.log('ok')});
